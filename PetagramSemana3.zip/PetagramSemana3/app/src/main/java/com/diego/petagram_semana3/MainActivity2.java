package com.diego.petagram_semana3;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    private List<Perro> perros;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        perros = getAllPerros();
        mRecyclerView = findViewById(R.id.Recycler2);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new MyAdapter(perros, R.layout.recycler_view_item, new MyAdapter.OnItemClickListener(){
            @Override
            public void onItemClick(Perro perro, int position) {
                Toast.makeText(MainActivity2.this, perro.nombre + " " + position, Toast.LENGTH_SHORT).show();
            }
        });

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
    }

    public List<Perro> getAllPerros(){

        return new ArrayList<Perro>(){{
            Perro perro1 = new Perro("perro1", R.drawable.perro1, 0);
            Perro perro2 = new Perro("perro2", R.drawable.perro2, 0);
            Perro perro3 = new Perro("perro3", R.drawable.perro3, 0);
            Perro perro4 = new Perro("perro4", R.drawable.perro4, 0);
            Perro perro5 = new Perro("perro5", R.drawable.perro5, 0);
            add(perro1);
            add(perro2);
            add(perro3);
            add(perro4);
            add(perro5);
        }};
    }
}