package com.diego.petagram_semana3;

import java.io.Serializable;

public class Perro implements Serializable {
    String nombre;
    int id;
    int imagen;
    int likes;


    public Perro(String nombre, int imagen, int likes, int id) {
        this.nombre = nombre;
        this.imagen = imagen;
        this.likes = likes;
        this.id = id;
    }

    public Perro() {

    }

    public Perro(String perro1, int perro11, int i) {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
