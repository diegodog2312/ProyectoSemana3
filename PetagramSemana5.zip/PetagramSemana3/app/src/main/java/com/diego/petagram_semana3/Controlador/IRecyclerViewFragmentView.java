package com.diego.petagram_semana3.Controlador;

import com.diego.petagram_semana3.MyAdapter;
import com.diego.petagram_semana3.Perro;

import java.util.ArrayList;

public interface IRecyclerViewFragmentView {
    public void generarLinearLayoutVertical();
    public MyAdapter crearAdaptador(ArrayList<Perro> perros);
    public void inicializarAdaptadorRV(MyAdapter adapter);
}
