package com.diego.petagram_semana3.presentador;

public interface IRecyclerViewFragmentPresenter {
    public void obtenerPerrosBaseDatos();
    public void mostrarPerrosRV();
}
