package com.diego.petagram_semana3.db;

public final class ConstantesBaseDatos {
    public static final String DATABASE_NAME = "perros";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_CONTACTS = "perro";
    public static final String TABLE_CONTACTS_ID = "id";
    public static final String TABLE_CONTACTS_NOMBRE = "nombre";
    public static final String TABLE_CONTACTS_IMAGEN = "imagen";
    public static final String TABLE_LIKES_CONTACT = "perros_likes";
    public static final String TABLE_LIKES_CONTACT_ID = "id";
    public static final String TABLE_LIKES_CONTACT_ID_PERRO = "id_perro";
    public static final String TABLE_LIKES_CONTACT_NUMERO_LIKES = "numero_likes";
}