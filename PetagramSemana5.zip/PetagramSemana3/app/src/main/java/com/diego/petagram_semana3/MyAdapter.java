package com.diego.petagram_semana3;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.diego.petagram_semana3.db.ConstructorPerros;

import java.util.List;

public class MyAdapter extends  RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private List<Perro> perros;
    private  int layout;
    private OnItemClickListener listener;

    public MyAdapter(List<Perro> perros, int layout, OnItemClickListener listener){
        this.perros = perros;
        this.layout = layout;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.bind(perros.get(position), listener);
    }

    @Override
    public int getItemCount() {
        return perros.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        private TextView name;
        private ImageView imagen;
        private TextView likes;
        private ImageButton imageButton;
        Context context;

        public ViewHolder(View view){
            super(view);
            this.name = (TextView) view.findViewById(R.id.textView);
            this.imagen = (ImageView) view.findViewById(R.id.imageView);
            this.likes = (TextView) view.findViewById(R.id.likes);
            this.imageButton = (ImageButton) view.findViewById(R.id.imageButton);
        }

        public void bind(final  Perro perro, final OnItemClickListener listener){
            this.name.setText(perro.getNombre());
            this.imagen.setImageResource(perro.getImagen());
            this.likes.setText(""+perro.getLikes());

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onItemClick(perro, getAdapterPosition());
                }
            });

            imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    context = view.getContext();
                    ConstructorPerros constructorPerros = new ConstructorPerros(context);
                    constructorPerros.darLikePerro(perro);
                    likes.setText(constructorPerros.obtenerLikesPerro(perro));
                }
            });
        }
    }

    public interface OnItemClickListener{
        void onItemClick(Perro perro, int position);
    }
}
