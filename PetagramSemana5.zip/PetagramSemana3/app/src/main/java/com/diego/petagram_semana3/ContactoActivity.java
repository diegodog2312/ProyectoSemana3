package com.diego.petagram_semana3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class ContactoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    public void enviarMensaje(View view){
        Toast.makeText(this, "Mensaje enviado", Toast.LENGTH_SHORT).show();
    }
}