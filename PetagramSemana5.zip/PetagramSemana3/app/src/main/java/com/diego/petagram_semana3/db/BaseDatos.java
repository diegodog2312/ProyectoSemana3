package com.diego.petagram_semana3.db;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.diego.petagram_semana3.Perro;

import java.util.ArrayList;


public class BaseDatos extends SQLiteOpenHelper {

    private Context context;

    public BaseDatos(Context context){
        super(context, ConstantesBaseDatos.DATABASE_NAME, null, ConstantesBaseDatos.DATABASE_VERSION);
        this.context = context;

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String queryCrearTablaPerro  = "CREATE TABLE " + ConstantesBaseDatos.TABLE_CONTACTS + "(" +
                                        ConstantesBaseDatos.TABLE_CONTACTS_ID       + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                        ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE   + " TEXT, " +
                                        ConstantesBaseDatos.TABLE_CONTACTS_IMAGEN   + " INTEGER" +
                                        ")";

        String queryCrearTablaLikes = "CREATE TABLE " + ConstantesBaseDatos.TABLE_LIKES_CONTACT + "("+
                                        ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                        ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_PERRO + " INTEGER, " +
                                        ConstantesBaseDatos.TABLE_LIKES_CONTACT_NUMERO_LIKES + " INTEGER, " +
                                        "FOREIGN KEY (" + ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_PERRO+ ") " +
                                        "REFERENCES " + ConstantesBaseDatos.TABLE_CONTACTS + "("+ConstantesBaseDatos.TABLE_CONTACTS_ID+")"+
                                        ")";

        db.execSQL(queryCrearTablaPerro);
        db.execSQL(queryCrearTablaLikes);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+ConstantesBaseDatos.TABLE_CONTACTS);
        db.execSQL("DROP TABLE IF EXISTS "+ConstantesBaseDatos.TABLE_LIKES_CONTACT);
        onCreate(db);
    }

    public ArrayList<Perro> obtenerTodoslosPerros(){
        ArrayList<Perro> perros = new ArrayList<>();

        String query = "SELECT * FROM " + ConstantesBaseDatos.TABLE_CONTACTS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);

        while (registros.moveToNext()){
            Perro perroActual = new Perro();
            perroActual.setId(registros.getInt(0));
            perroActual.setNombre(registros.getString(1));
            perroActual.setImagen(registros.getInt(2));

            String queryLikes = "SELECT COUNT("+ConstantesBaseDatos.TABLE_LIKES_CONTACT_NUMERO_LIKES+") as likes "+
                                " FROM " + ConstantesBaseDatos.TABLE_LIKES_CONTACT +
                                " WHERE " + ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_PERRO + "=" + perroActual.getId();

            Cursor registroslikes = db.rawQuery(queryLikes, null);
            if(registros.moveToNext()){
                perroActual.setLikes(registroslikes.getInt(0));
            } else {
                perroActual.setLikes(0);
            }
            perros.add(perroActual);
        }

        db.close();
        return perros;
    }

    public void insertarPerro(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_CONTACTS, null, contentValues);
        db.close();
    }

    public void insertarLikePerro(ContentValues contentValues){
        SQLiteDatabase db= this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_LIKES_CONTACT, null, contentValues);
        db.close();
    }

    public int obtenerLikesPerro(Perro perro){
        int likes = 0;

        String query = "SELECT COUNT("+ConstantesBaseDatos.TABLE_LIKES_CONTACT_NUMERO_LIKES+")"+
                        " FROM "+ConstantesBaseDatos.TABLE_LIKES_CONTACT +
                        " WHERE " + ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_PERRO + "=" + perro.getId();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);

        if (registros.moveToNext()){
            likes = registros.getInt(0);
        }

        db.close();

        return likes;
    }
}