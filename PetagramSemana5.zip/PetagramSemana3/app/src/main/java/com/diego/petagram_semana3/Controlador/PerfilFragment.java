package com.diego.petagram_semana3.Controlador;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.diego.petagram_semana3.MyAdapter;
import com.diego.petagram_semana3.Perro;
import com.diego.petagram_semana3.R;

import java.util.ArrayList;

public class PerfilFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public ArrayList<Perro> perros;
    public RecyclerView mRecyclerView;
    public RecyclerView.Adapter mAdapter;
    public RecyclerView.LayoutManager mLayoutManager;

    public PerfilFragment() {
        // Required empty public constructor
    }

    public static PerfilFragment newInstance(String param1, String param2) {
        PerfilFragment fragment = new PerfilFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View v = inflater.inflate(R.layout.fragment_perfil, container, false);
        inicializarPerros();

        mRecyclerView = v.findViewById(R.id.RecyclerF2);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mAdapter = new MyAdapter(perros, R.layout.recycler_view_item, new MyAdapter.OnItemClickListener(){
            @Override
            public void onItemClick(Perro perro, int position) {
                Toast.makeText(getActivity(), perro.getNombre() + " " + position, Toast.LENGTH_SHORT).show();
            }
        });

        mRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 3));
        mRecyclerView.setAdapter(mAdapter);
        return v;
    }

    public void inicializarPerros(){
        perros = new ArrayList<Perro>();
        perros.add(new Perro("perro1", R.drawable.perro1, 0));
        perros.add(new Perro("perro2", R.drawable.perro2, 0));
        perros.add(new Perro("perro3", R.drawable.perro3, 0));
        perros.add(new Perro("perro4", R.drawable.perro4, 0));
        perros.add(new Perro("perro5", R.drawable.perro5, 0));
    }
}