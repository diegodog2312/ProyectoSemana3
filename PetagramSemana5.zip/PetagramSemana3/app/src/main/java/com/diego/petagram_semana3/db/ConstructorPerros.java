package com.diego.petagram_semana3.db;

import android.content.ContentValues;
import android.content.Context;

import com.diego.petagram_semana3.Perro;
import com.diego.petagram_semana3.R;

import java.util.ArrayList;

public class ConstructorPerros {
    private static final int LIKE = 1;
    private Context context;

    public ConstructorPerros(Context context){
        this.context = context;
    }

    public ArrayList<Perro> obtenerDatos(){
        BaseDatos db = new BaseDatos(context);
        insertarPerros(db);
        return db.obtenerTodoslosPerros();
    }

    public void insertarPerros(BaseDatos db){
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE, "perro1");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_IMAGEN, R.drawable.perro1);

        db.insertarPerro(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE, "perro2");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_IMAGEN, R.drawable.perro2);

        db.insertarPerro(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE, "perro3");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_IMAGEN, R.drawable.perro3);

        db.insertarPerro(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE, "perro4");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_IMAGEN, R.drawable.perro4);

        db.insertarPerro(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_NOMBRE, "perro5");
        contentValues.put(ConstantesBaseDatos.TABLE_CONTACTS_IMAGEN, R.drawable.perro5);

        db.insertarPerro(contentValues);

    }

    public void darLikePerro(Perro perro){
        BaseDatos db = new BaseDatos(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_CONTACT_ID_PERRO, perro.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_LIKES_CONTACT_NUMERO_LIKES, LIKE);
        db.insertarLikePerro(contentValues);
    }

    public int obtenerLikesPerro(Perro perro){
        BaseDatos db = new BaseDatos(context);
        return db.obtenerLikesPerro(perro);
    }
}
