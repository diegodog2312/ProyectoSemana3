package com.diego.petagram_semana3.presentador;

import android.content.Context;

import androidx.core.content.ContextCompat;

import com.diego.petagram_semana3.Controlador.IRecyclerViewFragmentView;
import com.diego.petagram_semana3.Perro;
import com.diego.petagram_semana3.db.ConstructorPerros;

import java.util.ArrayList;

public class RecyclerViewFragmentPresenter implements IRecyclerViewFragmentPresenter{

    private IRecyclerViewFragmentPresenter iRecyclerViewFragmentPresenter;
    private IRecyclerViewFragmentView iRecyclerViewFragmentView;
    private Context context;
    private ConstructorPerros constructorPerros;
    private ArrayList<Perro> perros;
    public RecyclerViewFragmentPresenter(IRecyclerViewFragmentView iRecyclerViewFragmentView, Context context) {
        this.iRecyclerViewFragmentView = iRecyclerViewFragmentView;
        this.context = context;
        obtenerPerrosBaseDatos();
    }

    @Override
    public void obtenerPerrosBaseDatos() {
        constructorPerros = new ConstructorPerros(context);
        perros = constructorPerros.obtenerDatos();
        mostrarPerrosRV();
    }

    @Override
    public void mostrarPerrosRV() {
        iRecyclerViewFragmentView.inicializarAdaptadorRV(iRecyclerViewFragmentView.crearAdaptador(perros));
        iRecyclerViewFragmentView.generarLinearLayoutVertical();
    }
}
