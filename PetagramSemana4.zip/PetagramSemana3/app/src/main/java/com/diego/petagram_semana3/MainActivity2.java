package com.diego.petagram_semana3;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    private ArrayList<Perro> perros;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Bundle parametros = getIntent().getExtras();
        perros = (ArrayList<Perro>) parametros.getSerializable("perros");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mRecyclerView = findViewById(R.id.Recycler2);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new MyAdapter(perros, R.layout.recycler_view_item, new MyAdapter.OnItemClickListener(){
            @Override
            public void onItemClick(Perro perro, int position) {
                Toast.makeText(MainActivity2.this, perro.nombre + " " + position, Toast.LENGTH_SHORT).show();
            }
        });

        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
    }

}